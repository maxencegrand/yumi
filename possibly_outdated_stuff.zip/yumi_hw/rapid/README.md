This folder contains rapid code that needs to be installed on the yumi controller in order to run the hardware interface online.
